<?php
if(is_page()) echo ' >is_page< '; //ToDo Test "IS"
if(is_home()) echo ' >is_home< '; //ToDo Test "IS"
if(is_front_page()) echo ' >is_front_page< '; //ToDo Test "IS"
if(is_single()) echo ' >is_single< '; //ToDo Test "IS"
if(is_category()) echo ' >is_category< '; //ToDo Test "IS"
if(is_page_template()) echo ' >is_page_template< '; //ToDo Test "IS"