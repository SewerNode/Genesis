<h1>Webrun1 on Genesis Sandbox</h1>

<h3>Functions File (functions.php)</h3>
<p>This file contains the bulk of the heavy lifting for the child theme. In this file, you will find the following:</p>
<ol>
    <li>Content Width</li>
    <li>Structural Wraps</li>
    <li>Featured Image</li>
	<li>Genesis Custom Header</li>
	<li>Footer Widgets</li>
	<li>Top/Footer Navigation</li>
	<li>Customized Footer</li>
	<li>Genesis Responsive</li>
	<li>Scripts</li>
	<li>Editor Style</li>
	<li>Add/Remove Sidebars</li>
	<li>Remove Unused Layouts</li>
	<li>Customize More Links</li>
	<li>Remove Edit Link</li>
	<li>Remove Unused Contact Methods</li>
</ol>
